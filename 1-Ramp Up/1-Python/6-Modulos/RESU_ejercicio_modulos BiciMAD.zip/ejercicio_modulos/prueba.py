import pandas as pd

print("Funciona")